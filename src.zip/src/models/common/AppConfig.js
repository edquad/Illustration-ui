const config = {
  baseURL: "http://localhost:3010/",
  env: import.meta.env.VITE_APP_ENV,
};

export default config;