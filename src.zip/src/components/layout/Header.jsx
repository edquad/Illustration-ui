import React from "react";
import {
  AppBar,
  Toolbar,
  IconButton,
  Box,
  Avatar,
} from "@mui/material";
import MenuOpenIcon from "@mui/icons-material/MenuOpen";
import { useApp } from "../AppProvider";
import PersonIcon from "@mui/icons-material/Person";
import { useLocation } from "react-router-dom";
import { useAuth0 } from "@auth0/auth0-react";
import { useEffect, useState } from "react";
import { useApi } from '../../hooks/useApi';

const Profile = () => {
  const { user, isAuthenticated, isLoading } = useAuth0();
  const [userMetadata, setUserMetadata] = useState(null);
  const api = useApi();

  useEffect(() => {
    const getUserMetadata = async () => {
      const domain = "illustration.sandbox1.ceresinsurance.com";
      try {
        // Now using the centralized API service
        const userDetailsByIdUrl = `https://${domain}/api/v2/users/${user.sub}`;
        const response = await fetch(userDetailsByIdUrl, {
          headers: await api.getAuthHeaders(), // Get headers from API service
        });
        
        const { user_metadata } = await response.json();
        setUserMetadata(user_metadata);
      } catch (e) {
        console.log(e.message);
      }
    };
    
    if (isAuthenticated && user) {
      getUserMetadata();
    }
  }, [isAuthenticated, user, api]);

  if (isLoading) {
    return <div>Loading ...</div>;
  }

  return (
    isAuthenticated && (
      <div>
        <img src={user.picture} alt={user.name} />
        <h2>{user.name}</h2>
        <p>{user.email}</p>
        {userMetadata ? (
          <pre>{JSON.stringify(userMetadata, null, 2)}</pre>
        ) : (
          "No user metadata defined"
        )}
      </div>
    )
  );
};
const LogoutButton = () => {
  const { logout } = useAuth0();

  return (
    <button onClick={() => logout({ logoutParams: { returnTo: window.location.origin } })}>
      Log Out
    </button>
  );
};

const Header = ({ onMenuClick, headerRight }) => {
  const location = useLocation();
  const { user, logo } = useApp();

  return (
    <AppBar
      position="static"
      color="inherit"
      elevation={0}
      sx={{ borderBottom: "1px solid #eee", zIndex: 1201 }}
    >
      <Toolbar>
        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          sx={{ mr: 2 }}
          onClick={onMenuClick}
        >
          <MenuOpenIcon />
        </IconButton>
        <Box sx={{ flexGrow: 1 }} />
        <Avatar sx={{ mr: 1 }}>
          <PersonIcon />
        </Avatar>
        <strong>{user ? `${user.name}` : ""}</strong>
        <Profile />
        <LogoutButton />
        {headerRight}
      </Toolbar>
    </AppBar>
  );
};

export default Header;