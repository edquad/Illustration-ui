import apiService from '../services/ApiService';

// Get all products
export async function getAllProducts() {
  try {
    const response = await apiService.get('api/admin/products');
    return response;
  } catch (error) {
    throw error;
  }
}

// Get all terms
export const getAllTerms = async () => {
  return await apiService.get('api/admin/terms');
};

export const getTermById = async (id) => {
  return await apiService.get(`api/admin/terms/${id}`);
};

export const createTerm = async (termData) => {
  return await apiService.post('api/admin/terms', termData);
};

export const updateTerm = async (id, termData) => {
  return await apiService.put(`api/admin/terms/${id}`, termData);
};

export const deleteTerm = async (id) => {
  return await apiService.delete(`api/admin/terms/${id}`);
};

// Withdrawal Type API functions
export const getAllWithdrawalTypes = async () => {
  return await apiService.get('api/admin/withdrawal-types');
};

export const getWithdrawalTypeById = async (id) => {
  return await apiService.get(`api/admin/withdrawal-types/${id}`);
};

export const createWithdrawalType = async (data) => {
  return await apiService.post('api/admin/withdrawal-types', data);
};

export const updateWithdrawalType = async (id, data) => {
  return await apiService.put(`api/admin/withdrawal-types/${id}`, data);
};

export const deleteWithdrawalType = async (id) => {
  return await apiService.delete(`api/admin/withdrawal-types/${id}`);
};