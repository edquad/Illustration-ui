import IllustrationInfoForm from "../components/illustration/IllustrationInfoForm";
function Illustration() {
  return (
    <>
      <IllustrationInfoForm />
    </>
  );
}

export default Illustration;
